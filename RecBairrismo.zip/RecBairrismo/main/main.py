import func.f as ff
from time import asctime


login = False
info_save = []
carrinho = [0, 0, 0, 0]


filmes = ['Bacurau']

username = ''
usuario_linha = ''
linha = ''

ingresso_precos = (10, 6)
tot_inteira = 0
tot_meias = 0


opcao_principal = -1
opcao_entcad = -1
opcao_conta = 0
opcao_sobre = 0
opcao_ingresso = -1
salvar_info_filme = 0
opcao_compra = -2
opcao_carrinho = 0

while True:
    ff.conclear()

    if not login:
        try:
            print()
            ff.titulo("Menu - Cinema São Luiz")
            print()
            print(ff.pintar("amaNI", "Selecione Uma Opção:"))
            print()
            print(f'{ff.pintar("amaNI", "[1]  ")}Sobre o Cinema\n'
                  f'{ff.pintar("amaNI", "[2]  ")}Programação e Ingressos\n'
                  f'{ff.pintar("amaNI", "[3]  ")}Entrar/Cadastrar\n'
                  f'{ff.pintar("amaNI", "[0]  ")}Sair do Programa\n')
            opcao_principal = int(input(f'{ff.pintar("cinNI", "►►► ")}'))
        except ValueError:
            ff.error()

    if login:
        try:
            print()
            print(f'{ff.pintar("noInv", f"Bem-vindo {info_save[0]}")}')
            print()
            ff.titulo("Menu - Cinema Sao Luiz")
            print()
            print(ff.pintar("amaNI", "Selecione Uma Opção: "))
            print()
            print(f'{ff.pintar("amaNI", "[1]  ")}Sobre o Cinema\n'
                  f'{ff.pintar("amaNI", "[2]  ")}Programação e Ingressos\n'
                  f'{ff.pintar("amaNI", "[3]  ")}Minha Conta\n'
                  f'{ff.pintar("amaNI", "[4]  ")}Carrinho\n'
                  f'{ff.pintar("amaNI", "[0]  ")}Sair do Programa\n')
            opcao_principal = int(input(f'{ff.pintar("cinNI", "►►► ")}'))
        except ValueError:
            ff.error()

    if opcao_principal == 0:
        print()
        print(f'Encerrando', end=' ')
        ff.dormir()
        break

    if opcao_principal == 1:
        ff.conclear()
        while True:
            try:
                print(f'{ff.pintar("amaNI", "[1] ")}Sobre o Cinema\n'
                      f'{ff.pintar("amaNI", "[2] ")}Contatos\n'
                      f'{ff.pintar("amaNI", "[0] ")}Voltar')
                opcao_sobre = int(input(f'{ff.pintar("cinNI", "►►► ")}'))
            except ValueError:
                ff.error()
            if opcao_sobre == 0:
                print()
                print('Voltando', end=' ')
                ff.dormir()
                break
            elif opcao_sobre == 1:
                ff.conclear()
                arq_sobre = open('arquivoSobre.txt', 'r', encoding='utf8')
                print(arq_sobre.read())
                arq_sobre.close()
                print()
                input('Pressione ENTER para continuar . . .')
                continue
            elif opcao_sobre == 2:
                ff.conclear()
                arq_contatos = open('arquivoContatos.txt', 'r', encoding='utf8')
                print(arq_contatos.read())
                arq_contatos.close()
                print()
                input('Pressione ENTER para continuar . . .')
                continue

    if opcao_principal == 2:
        total_ingressos = []


        ff.conclear()

        time = asctime()
        time_split = time.split()
        time_day = time_split[0]
        dia = time_day

        if time_day == 'Tue':
            ingresso_inteiro = ingresso_precos[1]
        else:
            ingresso_inteiro = ingresso_precos[0]

        try:
            print(f'{ff.pintar("amaNI", "Escolha o filme")}')
            print()
            print('Filmes:')
            print('-' * 32)
            for num, filme_titulo in enumerate(filmes):
                print(f'[{num+1}]  {filme_titulo}')
            print('-' * 32)
            opcao_ingresso = int(input(f'{ff.pintar("cinNI", "►►► ")}'))
        except ValueError:
            ff.error()

        escolha_filme = opcao_ingresso - 1
        filme_escolhido = filmes[escolha_filme]

        print('-' * 45)
        pergunta_filme = input(f'Deseja comprar ingressos para: {filme_escolhido}? S|N ').upper()
        while pergunta_filme not in 'SN':
            print()
            print(f'{ff.pintar("noInv", "OPCAO INVALIDA, TENTE NOVAMENTE")}')
            pergunta_filme = input(f'Deseja comprar ingressos para: {filme_escolhido}? S|N ').upper()
        if pergunta_filme == 'N':
            print()
            print(f'{ff.pintar("noInv", "OPERACAO CANCELADA PELO USUARIO")}')
            print('Voltando', end=' ')
            ff.dormir()
            break
        else:
            while True:
                arq_filmes = open('filmes.txt', 'r', encoding='utf8')
                arq_filmes_ler = arq_filmes.readlines()
                arq_filmes.close()
                for linhas in arq_filmes_ler:
                    if filme_escolhido in linhas:
                        salvar_info_filme = linhas
                        break
                salvar_info_filme_split = salvar_info_filme.split()
                print('-'*45)
                print(f'NOME: {salvar_info_filme_split[0]}\n'
                      f'******\n'
                      f'******\n'
                      f'*FOTO*      NOTA: {salvar_info_filme_split[2]}\n'
                      f'******\n'
                      f'******\n'
                      f'\n'
                      f'Elenco: {salvar_info_filme_split[4]}\n'
                      f'Direcao: {salvar_info_filme_split[6]}\n'
                      f'Genero: {salvar_info_filme_split[8]}\n'
                      f'Duracao: {salvar_info_filme_split[10]} Minutos\n'
                      f'Distribuidora: {salvar_info_filme_split[12]}\n'
                      f'Classificacao: {salvar_info_filme_split[14]}Anos\n')
                print('-' * 45)
                try:
                    ff.conclear()
                    print()
                    print(f'{ff.pintar("amaNI", "[0]  ")}Finalizar')
                    print(f'{ff.pintar("amaNI", "[1]  ")}Inteira - R$ {ingresso_inteiro}\n'
                          f'{ff.pintar("amaNI", "[2]  ")}Meia    - R$ {ingresso_inteiro/2}\n'
                          f'{ff.pintar("amaNI", "[-1] ")}Cancelar Operacao\n')
                    print()
                    opcao_compra = int(input(f'{ff.pintar("cinNI", "►►► ")}'))
                except ValueError:
                    ff.error()

                if opcao_compra == -1:
                    print()
                    print(f'{ff.pintar("noInv", "OPERACAO CANCELADA PELO USUARIO")}')
                    carrinho.clear()
                    print('Voltando', end=' ')
                    ff.dormir()
                    break
                elif opcao_compra == 0:
                    print()
                    if sum(carrinho) == 0:
                        print(f'{ff.pintar("noInv", "NADA FOI ADICIONADO")}')
                        print(f'Voltando', end=' ')
                        ff.dormir()
                        break
                    else:
                        if login:
                            print()
                            print(
                                f'{ff.pintar("noInv", "PRODUTOS ADICIONADOS AO CARRINHO, VA AO CARRINHO PARA FINALIZAR")}')
                            print('Voltando', end=' ')
                            ff.dormir()
                            break
                        else:
                            print()
                            print(f'{ff.pintar("noInv", "PRODUTOS ADICIONADOS AO CARRINHO, FACA LOGIN PARA TERMINAR A COMPRA.")}')
                            print('Voltando', end=' ')
                            ff.dormir()
                            break
                elif opcao_compra == 1:
                    comprar_inteiras = int(input('Quantas inteiras comprar? '))
                    tot_inteira += comprar_inteiras
                    soma_inteiras = tot_inteira * ingresso_inteiro
                    carrinho[0] = tot_inteira
                    carrinho[1] = soma_inteiras
                elif opcao_compra == 2:
                    comprar_meias = int(input('Quantas meias comprar? '))
                    tot_meias += comprar_meias
                    soma_meias = tot_meias * (ingresso_inteiro/2)
                    carrinho[2] = tot_meias
                    carrinho[3] = soma_meias

    if opcao_principal == 3 and not login:
        while True:
            try:
                ff.conclear()
                print(f'{ff.pintar("amaNI", "[1] ")}Entrar\n'
                      f'{ff.pintar("amaNI", "[2] ")}Cadastrar\n'
                      f'{ff.pintar("amaNI", "[0] ")}Voltar ao Menu Principal\n')
                opcao_entcad = int(input(f'{ff.pintar("cinNI", "►►► ")}'))
            except ValueError:
                ff.error()

            if opcao_entcad == 0:
                print()
                print(f'Voltando ao Menu Principal', end=' ')
                ff.dormir()
                break

            if opcao_entcad == 2:
                ff.conclear()
                while True:
                    pergunta = input('Deseja iniciar o cadastro? S|N ').upper()
                    while pergunta not in 'SN' or len(pergunta) != 1:
                        print()
                        print(f'{ff.pintar("noInv", "OPCAO INVALIDA, TENTE NOVAMENTE.")}')
                        print()
                        pergunta = input('Deseja iniciar o cadastro? S|N ').upper()
                    if pergunta == 'N':
                        print()
                        print(f'{ff.pintar("noInv", "OPERACAO CANCELADA PELO USUARIO")}')
                        print()
                        print('Voltando a tela de escolha', end=' ')
                        ff.dormir()
                        break
                    else:
                        ff.conclear()
                        arq_usu = open('usuarios.txt', 'r', encoding='utf8')
                        arq_usu_ler = arq_usu.readlines()
                        username = input(f'{ff.pintar("vermNIS", "NOME DE USUARIO")}\n')

                        switch = False

                        for linhas in arq_usu_ler:
                            if username in linhas:
                                switch = True
                                break

                        if switch:
                            print()
                            print(f'{ff.pintar("noInv", "USUARIO JA CADASTRADO")}\n')
                            print('Voltando a opcao de cadastro', end=' ')
                            ff.dormir()
                            arq_usu.close()
                            break

                        else:
                            password = input(f'{ff.pintar("amaNIS", "SENHA")}\n')
                            email = input(f'{ff.pintar("vermNIS", "E-MAIL")}\n')
                            nome = input(f'{ff.pintar("amaNIS", "NOME")}\n').strip().title().split()
                            nome_join = ''.join(nome)

                            arq_usu_append = open('usuarios.txt', 'a', encoding='utf8')
                            arq_usu_append.write(f'{username} # {password} # {email} # {nome_join}\n')
                            arq_usu_append.close()

                            print()
                            print(f'{ff.pintar("noInv", "USUARIO CADASTRADO COM SUCESSO")}')
                            print()
                            print(f'Voltando', end=' ')
                            ff.dormir()
                            break
                break

            if opcao_entcad == 1:
                ff.conclear()
                info_save = []
                while True:
                    arq_usu = open('usuarios.txt', 'r', encoding='utf8')
                    arq_usu_ler = arq_usu.readlines()
                    username_pesquisa = input(f'{ff.pintar("vermNIS", "NOME DE USUARIO")}\n')

                    switch_usu = False

                    for linha in arq_usu_ler:
                        if username_pesquisa in linha:
                            usuario_linha = linha
                            switch_usu = True
                            break
                    if not switch_usu:
                        print()
                        print(f'{ff.pintar("noInv", "USUARIO NAO ENCONTRADO")}')
                        print('Voltando', end=' ')
                        ff.dormir()
                        break
                    else:
                        print()
                        senha_pesquisa = input(f'{ff.pintar("amaNIS", "SENHA")}\n')
                        if senha_pesquisa not in linha:
                            print()
                            print(f'{ff.pintar("noInv", "SENHA INCORRETA")}')
                            print('Voltando', end=' ')
                            ff.dormir()
                        else:
                            usuario_linha_split = usuario_linha.split()
                            print()
                            login = True
                            print(f'{ff.pintar("noInv", "LOGADO COM SUCESSO!")}')
                            print('Voltando ao Menu Principal', end=' ')
                            ff.dormir()
                            info_save = [usuario_linha_split[0], usuario_linha_split[2], usuario_linha_split[4], usuario_linha_split[6]]
                            opcao_principal = -1
                            break
                    arq_usu.close()
                    break
                break


    if opcao_principal == 3 and login:
        ff.conclear()
        while True:
            try:
                print(f'USUARIO:')
                print(f'{ff.pintar("amaNI", "~~" * 30)}\n')
                print(f'********\n'
                      f'**FOTO**       {ff.pintar("vermNIS", "NOME:")} {info_save[3]}\n'
                      f'********\n')
                print(f'{ff.pintar("amaNI", "~~" * 30)}')
                print(f'{ff.pintar("vermNIS", "NOME DE USUARIO:")} {info_save[0]}')
                print()
                print(f'{ff.pintar("vermNIS", "E-MAIL:")} {info_save[2]}')
                print()
                print(f'{ff.pintar("vermNIS", "SENHA:")} {info_save[1]}')
                print(f'{ff.pintar("amaNI", "~~" * 30)}')

                print(f'{ff.pintar("amaNI", "[1] ")}Voltar ao Menu\n'
                      f'{ff.pintar("amaNI", "[2] ")}Sair da Conta\n')
                opcao_conta = int(input(f'{ff.pintar("cinNI", "►►► ")}'))
            except ValueError:
                ff.error()

            if opcao_conta == 1:
                print()
                print('Voltando', end=' ')
                ff.dormir()
                break

            elif opcao_conta == 2:
                while True:
                    print()
                    pergunta_conta = input(f'Deseja Sair de {info_save[0]}? S|N ').upper()
                    while len(pergunta_conta) != 1 or pergunta_conta not in 'SN':
                        print()
                        print(f'{ff.pintar("noInv", "OPCAO INVALIDA, TENTE NOVAMENTE")}')
                        pergunta_conta = input(f'Deseja Sair de {info_save[0]}? S|N ').upper()
                    if pergunta_conta == 'N':
                        print()
                        print("OPERACAO CANCELADA PELO USUARIO")
                        print('Voltando', end=' ')
                        ff.dormir()
                        break
                    else:
                        print()
                        login = False
                        info_save.clear()
                        print(f'{ff.pintar("noInv", "VOCE SAIU DA CONTA")}')
                        print('Voltando ao Menu Principal', end=' ')
                        ff.dormir()
                        break
            break

    if opcao_principal == 4:
        ff.conclear()
        while True:
            if sum(carrinho) == 0:
                print(f'{ff.pintar("noInv", "NAO HA NADA NO CARRINHO")}')
                print('Voltando', end=' ')
                ff.dormir()
                break
            try:
                print('-' * 30)
                print(f'{ff.pintar("vermNIS", "CARRINHO")}')
                print('-' * 30)
                print(f'Ingressos Inteiros: {carrinho[0]}   Preco Inteiras: {carrinho[1]}\n'
                      f'Ingressos Meias   : {carrinho[2]}   Preco Meias   : {carrinho[3]}\n'
                      f'\n'
                      f'Total: {carrinho[1]+carrinho[3]}')
                print('-' * 30)
                print()
                print(f'{ff.pintar("amaNI", "[1] ")}Voltar\n'
                      f'{ff.pintar("amaNI", "[2] ")}Pagar com Boleto\n'
                      f'{ff.pintar("amaNI", "[3] ")}Pagar com Cartao\n')
                opcao_carrinho = int(input(f'{ff.pintar("cinNI", "►►► ")}'))
            except ValueError:
                ff.error()
            if opcao_carrinho == 1:
                print()
                print(f'Voltando', end=' ')
                ff.dormir()
                break
            else:
                print()
                print(f'Redirecionando', end=' ')
                ff.dormir()
                print(f'{ff.pintar("noInv", "PAGAMENTO EFETUADO COM SUCESSO!")}')
                carrinho.clear()
                input('Pressione ENTER para continuar . . .')
                break
ff.conclear()
print(f'{ff.pintar("noInv", "Programa finalizado pelo usuario")}')
print()
arq_integrante = open('integrantes.txt', 'r', encoding='utf8')
print(arq_integrante.read())
arq_integrante.close()
