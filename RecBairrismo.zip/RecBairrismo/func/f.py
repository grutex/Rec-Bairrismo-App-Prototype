from time import sleep


def conclear():
    """
    ☼► Printa 100 linhas para dar ideia que o console foi apagado.
    :return: nada
    """
    print('\n' * 130)

def pintar(cor, msg):
    c = ''
    """
    ☼ O que faz?
    ► Colore a mensagem de acordo com o codigo da pintura.


    ☼ Quais as Variaveis?
    cor - Codigo da cor a ser inserida.
    msg - mensagem , em STR, a ser colocada para ser pintada.


    ☼ Codigos
    [1] Original
        no - Nenhum
        bra - Branco
        verm - Vermelho
        verd - Verde
        ama - Amarelo
        az - Azul
        mag - Magenta
        cia - Ciano
        cin - Cinza

    [2] Modificadores
        N - Negrito
        I - Italico
        S - Sublinhado
        Inv - Inverte as cores

    [3] Exemplo
        f.pintar("codigo", "mensagem para ser pintada")
        f.pintar("amaNI", "Ola")

    return: Retorna a mensagem com a cor.
    """

    if cor == 'amaNI':
        c = f'\033[1;3;33m{msg}\033[m'
    elif cor == 'amaNIS':
        c = f'\033[1;3;4;33m{msg}\033[m'
    elif cor == 'cinNI':
        c = f'\033[1;3;37m{msg}\033[m'
    elif cor == 'noInv':
        c = f'\033[7m{msg}\033[m'
    elif cor == 'azNIS':
        c = f'\033[1;3;4;34m{msg}\033[m'
    elif cor == 'azNI':
        c = f'\033[1;3;34m{msg}\033[m'
    elif cor == 'magNI':
        c = f'\033[1;3;35m{msg}\033[m'
    elif cor == 'magNIS':
        c = f'\033[1;3;4;35m{msg}\033[m'
    elif cor == "vermNI":
        c = f'\033[1;3;31m{msg}\033[m'
    elif cor == "vermNIS":
        c = f'\033[1;3;4;31m{msg}\033[m'
    elif cor == "verdNI":
        c = f'\033[1;3;32m{msg}\033[m'
    elif cor == "verdNIS":
        c = f'\033[1;3;4;32m{msg}\033[m'
    return c



def titulo(msg):
    """
    ☼► Coloca a mensagem em forma de "titulo"
    :param msg: mensagem
    """
    tamanho = len(msg) + 6
    print(f'\033[1;3;31;100m~\033[m' * tamanho)
    print(f'\033[1;3;93;100m   {msg}   \033[m')
    print(f'\033[1;3;31;100m~\033[m' * tamanho)


def dormir():
    for i in range(1, 4):
        sleep(0.5)
        if i < 3:
            print(' .', end=' ')
        else:
            print(' .')
    sleep(0.5)


def error():
    print()
    print(pintar("noInv", "Opcao Invalida, tente novamente."))
    input('Pressione ENTER para continuar . . .')
    conclear()


